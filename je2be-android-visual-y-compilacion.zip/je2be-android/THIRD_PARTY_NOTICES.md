# Third-party notices

This Android app links the original `kbinani/je2be-core` C++ conversion engine, pinned to commit `8dfc4de1ba5c7f72e804abea8663380c0dbd5680`.

- JE2BE Core: GPL-3.0-or-later, see `LICENSE` and the upstream repository.
- AndroidX, Jetpack Compose, WorkManager and the Gradle Android plugins retain their respective upstream licenses.
- Native dependencies are fetched by JE2BE Core's own CPM configuration during the build; their license files remain in the downloaded dependency source trees.

This is an unofficial community Android port and is not affiliated with Mojang or Microsoft.
