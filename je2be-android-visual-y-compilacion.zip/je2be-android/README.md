# JE2BE Android

Interfaz Android nativa para el motor C++ original de JE2BE. No es un WebView ni envía los mundos a un servidor.

## Prioridad: fidelidad del conversor

El proyecto compila `je2be-core` desde la revisión fijada `8dfc4de1ba5c7f72e804abea8663380c0dbd5680`, documentada como la revisión enlazada por `kbinani/je2be-web`. CMake comprueba el hash exacto antes de continuar.

La app Android no vuelve a implementar la conversión de chunks, bloques, entidades, inventarios o metadatos en Kotlin. La capa Android se limita al acceso a archivos, directorios temporales, notificaciones, progreso, cancelación y la conexión JNI con el motor C++.

## Formatos incluidos

- Java → Bedrock
- Bedrock → Java
- Xbox 360 → Java
- Xbox 360 → Bedrock
- PS3 → Java
- PS3 → Bedrock

Las rutas de Xbox 360/PS3 → Bedrock pasan por un mundo Java intermedio, siguiendo el flujo del conversor upstream.

## Interfaz

La pantalla Android usa una interfaz oscura con acentos verde menta, selección de formato, lista de mundos, selector de destino, botón principal y tarjetas de progreso. Los cambios visuales no sustituyen ni modifican el motor de conversión.

## Compilación

El flujo de GitHub Actions está en `.github/workflows/build.yml`. Se ejecuta al subir cambios a `main` y también manualmente desde **Actions → Build JE2BE Android APK → Run workflow**.

El flujo usa JDK 17, Gradle 8.9, Android SDK 34, NDK 26.3.11579264 y CMake 3.22.1. El APK ARM64 se publica como artifact `JE2BE-Android-ARM64-debug`.

**Muy importante al subirlo a GitHub:** coloca el contenido de `je2be-android/` directamente en la raíz del repositorio, de modo que `settings.gradle.kts`, `app/` y `.github/` queden al mismo nivel.

Consulta [BUILD_MANUAL.md](BUILD_MANUAL.md) para los pasos desde el teléfono o para compilar localmente.

## Estado de pruebas

La revisión del motor está fijada, pero este proyecto todavía necesita completar una compilación Android real y pruebas de paridad con mundos copiados: convertir el mismo mundo en JE2BE Web y en Android, y comprobar que ambos resultados se abren y conservan sus datos. Por tanto, no se debe prometer equivalencia total hasta superar esas pruebas.

Conserva siempre una copia original de cada mundo. Las diferencias de arquitectura, memoria del dispositivo y acceso a archivos de Android aún pueden provocar errores específicos de plataforma.

## Licencia

JE2BE Core está bajo GPL-3.0. Conserva `LICENSE` y revisa `THIRD_PARTY_NOTICES.md` antes de distribuir versiones modificadas.
