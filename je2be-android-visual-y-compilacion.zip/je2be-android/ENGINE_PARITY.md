# Conversion engine parity

The official browser project `kbinani/je2be-web` links its `deps/je2be-core` submodule to commit:

`8dfc4de1ba5c7f72e804abea8663380c0dbd5680`

This Android project fetches that exact commit from `kbinani/je2be-core`. Its CMake configuration verifies the resolved Git revision before building. Both builds therefore compile the same upstream C++ world-conversion engine revision; Android uses the Android NDK toolchain instead of Emscripten.

Android-specific code is limited to document import/export, temporary directories, progress callbacks, cancellation, foreground work scheduling, and the JNI boundary. It does not translate chunks, blocks, entities, inventories, or world metadata itself.

The six Android routes are Java → Bedrock, Bedrock → Java, Xbox 360 → Java/Bedrock, and PS3 → Java/Bedrock. The legacy-console → Bedrock routes use the upstream two-stage conversion through an intermediate Java world.

**Verification limitation:** the same engine revision gives the project the basis for browser-level conversion fidelity, but the Android NDK build and real-world fixtures still need to pass. Architecture/ABI differences, Android memory limits, and file-import errors can still cause failures. Never convert the only copy of a world.
