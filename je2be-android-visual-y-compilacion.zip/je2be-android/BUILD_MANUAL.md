# Compilar JE2BE Android

## Opción 1: compilar manualmente desde GitHub (recomendada si no tienes PC)

El proyecto ya incluye el flujo manual de GitHub Actions. No tienes que pegar comandos en un archivo Kotlin.

### Dónde va el código de compilación

El archivo debe quedar exactamente en:

```text
.github/workflows/build.yml
```

Y la configuración que descarga y compila el motor nativo debe permanecer en:

```text
app/src/main/cpp/CMakeLists.txt
```

**Importante:** `build.yml` es el que inicia la compilación. `CMakeLists.txt` es el que descarga el motor original `je2be-core`, comprueba su commit y lo compila con el NDK para Android. No reemplaces ese commit por una versión inventada o por un conversor alternativo.

### Pasos desde el teléfono

1. Crea un repositorio en GitHub.
2. Descomprime este ZIP y sube el **contenido** de la carpeta `je2be-android` a la raíz del repositorio. La raíz debe mostrar `settings.gradle.kts`, `app/` y `.github/` directamente. No dejes todo metido dentro de otra carpeta `je2be-android/`.
3. Confirma los cambios en la rama `main`.
4. Abre la pestaña **Actions** del repositorio. Si GitHub muestra la opción para habilitar Actions, habilítala.
5. Selecciona **Build JE2BE Android APK**.
6. Pulsa **Run workflow**, elige `main` y vuelve a pulsar **Run workflow**. También se inicia automáticamente al subir cambios a `main`.
7. Cuando el trabajo termine con una marca verde, abre la ejecución y busca **Artifacts**.
8. Descarga `JE2BE-Android-ARM64-debug`. Dentro encontrarás `app-debug.apk`.

Si la ejecución falla, descarga los logs de esa ejecución y revisa el primer error real de Gradle, CMake o NDK. No cambies la revisión del motor para intentar ocultar un error de compilación.

## Opción 2: compilar desde un ordenador

Requisitos fijados por el proyecto:

- JDK 17.
- Gradle 8.9.
- Android SDK Platform 34 y Build Tools 34.0.0.
- Android NDK 26.3.11579264.
- CMake 3.22.1.
- Conexión a Internet durante la primera compilación, porque CMake descarga el código fuente fijado de JE2BE Core.

Desde la carpeta que contiene `settings.gradle.kts`, ejecuta:

```bash
gradle :app:assembleDebug --no-daemon --stacktrace
```

El APK queda en:

```text
app/build/outputs/apk/debug/app-debug.apk
```

En Android Studio también puedes abrir esa misma carpeta de proyecto y ejecutar la tarea `app > Tasks > build > assembleDebug`.

## Cómo conservar la calidad de conversión

El proyecto fija `je2be-core` al commit `8dfc4de1ba5c7f72e804abea8663380c0dbd5680`, la revisión que se documentó para `je2be-web`. CMake verifica el hash y detiene la compilación si no coincide.

No sustituyas `je2be-core` con código escrito en Kotlin, otro conversor ni una revisión distinta si el objetivo es mantener la misma base de conversión. La interfaz Android solo debe encargarse de elegir mundos, importar/exportar archivos, mostrar el progreso y llamar al motor nativo.

**Estado de validación:** compartir la misma revisión del motor es la base para igualar las conversiones, pero todavía hay que completar una compilación exitosa y comparar copias de los mismos mundos en JE2BE Web y Android. Haz siempre una copia de seguridad antes de convertir un mundo importante.
