package app.je2be.android

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.ServiceInfo
import android.net.Uri
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.work.Data
import androidx.work.ForegroundInfo
import androidx.work.Worker
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import java.io.File
import java.util.UUID
import java.util.concurrent.TimeUnit

class ConvertWorker(context: Context, parameters: WorkerParameters) : Worker(context, parameters) {
    override fun doWork(): Result {
        val inputText = inputData.getString(KEY_INPUT) ?: return failure("Falta el mundo de entrada.")
        val outputText = inputData.getString(KEY_OUTPUT) ?: return failure("Falta la carpeta de destino.")
        val isTree = inputData.getBoolean(KEY_INPUT_TREE, false)
        val inputName = inputData.getString(KEY_INPUT_NAME) ?: "Minecraft World"
        val mode = inputData.getInt(KEY_MODE, -1)
        if (mode !in 0..5) return failure("La ruta de conversión no es válida.")

        val jobDirectory = File(applicationContext.filesDir, "je2be-jobs/${id}")
        val nativeHandle = Native.newJob()
        try {
            jobDirectory.mkdirs()
            setForegroundAsync(foregroundInfo(inputName, "Preparando conversión…")).get(30, TimeUnit.SECONDS)

            val input = WorldStorage.importInput(
                applicationContext,
                Uri.parse(inputText),
                isTree,
                inputName,
                mode,
                File(jobDirectory, "input"),
                { stage, percent -> updateProgress(stage, percent) },
                { isStopped }
            )
            if (isStopped) return Result.failure()

            val output = File(jobDirectory, "output")
            output.mkdirs()
            updateProgress("Convirtiendo con JE2BE", 0)
            val error = Native.convert(
                nativeHandle,
                mode,
                input.absolutePath,
                output.absolutePath,
                File(jobDirectory, "temporary").absolutePath,
                1,
                Native.ProgressListener { stage, progress, count ->
                    if (isStopped) {
                        Native.cancel(nativeHandle)
                        false
                    } else {
                        val pct = (progress.coerceIn(0.0, 1.0) * 100.0).toInt()
                        setProgressAsync(workDataOf(KEY_STAGE to stage, KEY_PERCENT to pct, KEY_COUNT to count.toLong()))
                        true
                    }
                }
            )
            if (isStopped) return Result.failure()
            if (!error.isNullOrBlank()) return failure(error)

            val extension = if (mode == 0 || mode == 3 || mode == 5) ".mcworld" else ".zip"
            updateProgress("Empaquetando resultado", -1)
            val savedName = WorldStorage.exportWorld(
                applicationContext,
                Uri.parse(outputText),
                output,
                inputName,
                extension
            ) { isStopped }
            if (isStopped) return Result.failure()

            setProgressAsync(workDataOf(KEY_STAGE to "Terminado", KEY_PERCENT to 100))
            Result.success(workDataOf(KEY_SAVED_NAME to savedName))
        } catch (e: InterruptedException) {
            Result.failure(workDataOf(KEY_ERROR to (e.message ?: "Conversión cancelada.")))
        } catch (e: Exception) {
            failure(e.message ?: e.javaClass.simpleName)
        } finally {
            Native.freeJob(nativeHandle)
            jobDirectory.deleteRecursively()
        }
    }

    private fun updateProgress(stage: String, percent: Int) {
        val data = if (percent >= 0) workDataOf(KEY_STAGE to stage, KEY_PERCENT to percent)
        else workDataOf(KEY_STAGE to stage)
        setProgressAsync(data)
    }

    private fun failure(message: String): Result = Result.failure(workDataOf(KEY_ERROR to message))

    private fun foregroundInfo(world: String, detail: String): ForegroundInfo {
        val manager = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            manager.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "Conversiones JE2BE", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val notification = NotificationCompat.Builder(applicationContext, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle("JE2BE · $world")
            .setContentText(detail)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setProgress(0, 0, true)
            .build()
        return if (Build.VERSION.SDK_INT >= 29) {
            ForegroundInfo(id.hashCode(), notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            ForegroundInfo(id.hashCode(), notification)
        }
    }

    companion object {
        const val TAG = "je2be-conversion"
        const val KEY_INPUT = "input"
        const val KEY_INPUT_TREE = "inputTree"
        const val KEY_INPUT_NAME = "inputName"
        const val KEY_OUTPUT = "output"
        const val KEY_MODE = "mode"
        const val KEY_STAGE = "stage"
        const val KEY_PERCENT = "percent"
        const val KEY_COUNT = "count"
        const val KEY_ERROR = "error"
        const val KEY_SAVED_NAME = "savedName"
        private const val CHANNEL_ID = "je2be-conversion"
    }
}
