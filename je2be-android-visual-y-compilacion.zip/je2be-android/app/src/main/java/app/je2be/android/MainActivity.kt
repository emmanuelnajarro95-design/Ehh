package app.je2be.android

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.livedata.observeAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkInfo
import androidx.work.WorkManager
import androidx.work.workDataOf

private val Ink = Color(0xFF07121C)
private val Panel = Color(0xFF101F2B)
private val PanelRaised = Color(0xFF172B38)
private val Mint = Color(0xFF65F0C1)
private val Aqua = Color(0xFF59D8E8)
private val Muted = Color(0xFF9CB1BE)
private val SoftWhite = Color(0xFFEAF4F7)

private data class SelectedInput(val uri: Uri, val isTree: Boolean, val name: String)
private data class Mode(val id: Int, val title: String, val source: String, val target: String)

private val conversionModes = listOf(
    Mode(0, "Java → Bedrock", "JAVA", "BEDROCK"),
    Mode(1, "Bedrock → Java", "BEDROCK", "JAVA"),
    Mode(2, "Xbox 360 → Java", "XBOX 360", "JAVA"),
    Mode(3, "Xbox 360 → Bedrock", "XBOX 360", "BEDROCK"),
    Mode(4, "PS3 → Java", "PS3", "JAVA"),
    Mode(5, "PS3 → Bedrock", "PS3", "BEDROCK")
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 100)
        }
        val palette = darkColorScheme(
            primary = Mint,
            onPrimary = Ink,
            secondary = Aqua,
            background = Ink,
            surface = Panel,
            surfaceVariant = PanelRaised,
            onBackground = SoftWhite,
            onSurface = SoftWhite,
            onSurfaceVariant = Muted
        )
        setContent {
            MaterialTheme(colorScheme = palette) {
                Surface(modifier = Modifier.fillMaxSize(), color = Ink) {
                    Je2beScreen()
                }
            }
        }
    }
}

@Composable
private fun Je2beScreen() {
    val context = LocalContext.current
    val workManager = remember { WorkManager.getInstance(context) }
    val pending = remember { mutableStateListOf<SelectedInput>() }
    val jobs by workManager.getWorkInfosByTagLiveData(ConvertWorker.TAG).observeAsState(emptyList())
    var mode by remember { mutableIntStateOf(0) }
    var outputUri by remember { mutableStateOf<Uri?>(null) }
    var outputName by remember { mutableStateOf<String?>(null) }
    var message by remember { mutableStateOf<String?>(null) }

    fun keepRead(uri: Uri) {
        try {
            context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (_: SecurityException) {
            message = "Android no permitió conservar el acceso. Selecciona el archivo otra vez."
        }
    }

    val pickFolder = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            keepRead(uri)
            val name = androidx.documentfile.provider.DocumentFile.fromTreeUri(context, uri)?.name ?: "Minecraft World"
            pending.add(SelectedInput(uri, true, name))
            message = null
        }
    }
    val pickArchive = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            keepRead(uri)
            val name = displayName(context, uri) ?: "Minecraft World"
            pending.add(SelectedInput(uri, false, name))
            message = null
        }
    }
    val pickOutput = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            try {
                context.contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                )
                outputUri = uri
                outputName = androidx.documentfile.provider.DocumentFile.fromTreeUri(context, uri)?.name ?: "Carpeta seleccionada"
                message = null
            } catch (_: SecurityException) {
                message = "No se pudo conservar el permiso de escritura en esa carpeta."
            }
        }
    }

    Scaffold(containerColor = Ink) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 18.dp, vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(17.dp)
        ) {
            HeaderPanel()

            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                SectionHeading("01", "Tipo de conversión", "Selecciona el formato de origen y destino")
                conversionModes.chunked(2).forEach { pair ->
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        pair.forEach { item ->
                            ModeTile(
                                mode = item,
                                selected = mode == item.id,
                                modifier = Modifier.weight(1f),
                                onClick = { mode = item.id }
                            )
                        }
                        if (pair.size == 1) Spacer(Modifier.weight(1f))
                    }
                }
            }

            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                SectionHeading("02", "Tus mundos", "Añade uno o varios mundos a la cola")
                Card(
                    shape = RoundedCornerShape(22.dp),
                    colors = CardDefaults.cardColors(containerColor = Panel),
                    border = BorderStroke(1.dp, Color(0xFF203746))
                ) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(
                                onClick = { pickFolder.launch(null) },
                                enabled = mode != 2 && mode != 3,
                                modifier = Modifier.weight(1f),
                                border = BorderStroke(1.dp, Color(0xFF426071)),
                                shape = RoundedCornerShape(14.dp)
                            ) {
                                Text(if (mode == 4 || mode == 5) "Carpeta PS3" else "Carpeta", maxLines = 1)
                            }
                            OutlinedButton(
                                onClick = {
                                    val types = if (mode == 2 || mode == 3) arrayOf("application/octet-stream", "*/*")
                                    else arrayOf("application/zip", "application/octet-stream", "*/*")
                                    pickArchive.launch(types)
                                },
                                modifier = Modifier.weight(1f),
                                border = BorderStroke(1.dp, Color(0xFF426071)),
                                shape = RoundedCornerShape(14.dp)
                            ) {
                                Text(when (mode) {
                                    2, 3 -> "SAVE.BIN"
                                    4, 5 -> "GAMEDATA"
                                    else -> "ZIP / MCWORLD"
                                }, maxLines = 1)
                            }
                        }

                        if (pending.isEmpty()) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(16.dp))
                                    .background(Color(0xFF0B1923))
                                    .padding(vertical = 23.dp, horizontal = 12.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Text("＋", color = Mint, fontSize = 28.sp, fontWeight = FontWeight.Light)
                                    Text("Todavía no hay mundos", color = SoftWhite, fontWeight = FontWeight.SemiBold)
                                    Text("Usa uno de los botones para añadir un mundo", color = Muted, fontSize = 12.sp)
                                }
                            }
                        } else {
                            pending.forEachIndexed { index, item ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(13.dp))
                                        .background(Color(0xFF0B1923))
                                        .padding(start = 12.dp, end = 6.dp, top = 8.dp, bottom = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(30.dp)
                                            .clip(CircleShape)
                                            .background(Color(0xFF173B3A)),
                                        contentAlignment = Alignment.Center
                                    ) { Text("${index + 1}", color = Mint, fontWeight = FontWeight.Bold, fontSize = 12.sp) }
                                    Spacer(Modifier.width(10.dp))
                                    Text(item.name, modifier = Modifier.weight(1f), color = SoftWhite, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 13.sp)
                                    OutlinedButton(
                                        onClick = { pending.remove(item) },
                                        shape = RoundedCornerShape(11.dp),
                                        border = BorderStroke(1.dp, Color(0xFF354B59))
                                    ) { Text("Quitar", fontSize = 11.sp) }
                                }
                            }
                        }
                    }
                }
            }

            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                SectionHeading("03", "Destino", "Elige dónde guardar los mundos convertidos")
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = Panel),
                    border = BorderStroke(1.dp, Color(0xFF203746))
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Box(
                            modifier = Modifier.size(42.dp).clip(RoundedCornerShape(13.dp)).background(Color(0xFF173B3A)),
                            contentAlignment = Alignment.Center
                        ) { Text("↳", color = Mint, fontSize = 24.sp) }
                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                            Text(outputName ?: "Ninguna carpeta elegida", color = SoftWhite, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text("Carpeta de salida", color = Muted, fontSize = 12.sp)
                        }
                        OutlinedButton(
                            onClick = { pickOutput.launch(null) },
                            shape = RoundedCornerShape(13.dp),
                            border = BorderStroke(1.dp, Color(0xFF426071))
                        ) { Text("Elegir", fontSize = 12.sp) }
                    }
                }
            }

            Button(
                onClick = {
                    val destination = outputUri ?: return@Button
                    val selected = pending.toList()
                    selected.forEach { source ->
                        val request = OneTimeWorkRequestBuilder<ConvertWorker>()
                            .setInputData(
                                workDataOf(
                                    ConvertWorker.KEY_INPUT to source.uri.toString(),
                                    ConvertWorker.KEY_INPUT_TREE to source.isTree,
                                    ConvertWorker.KEY_INPUT_NAME to source.name,
                                    ConvertWorker.KEY_OUTPUT to destination.toString(),
                                    ConvertWorker.KEY_MODE to mode
                                )
                            )
                            .addTag(ConvertWorker.TAG)
                            .build()
                        workManager.enqueue(request)
                    }
                    pending.clear()
                    message = "Se añadieron ${selected.size} conversión(es) a la cola."
                },
                enabled = pending.isNotEmpty() && outputUri != null,
                modifier = Modifier.fillMaxWidth().height(54.dp),
                shape = RoundedCornerShape(17.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Mint, contentColor = Ink, disabledContainerColor = Color(0xFF263B45), disabledContentColor = Muted)
            ) {
                Text("INICIAR CONVERSIÓN", fontWeight = FontWeight.ExtraBold, letterSpacing = 1.sp)
                Spacer(Modifier.width(8.dp))
                Text("→", fontSize = 19.sp, fontWeight = FontWeight.Bold)
            }

            message?.let {
                Text(it, color = if (it.startsWith("Se añadieron")) Mint else Color(0xFFFFB5A7), fontSize = 12.sp)
            }

            Divider(color = Color(0xFF203746))
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Actividad", color = SoftWhite, fontSize = 21.sp, fontWeight = FontWeight.Bold)
                        Text("Estado de tus conversiones", color = Muted, fontSize = 12.sp)
                    }
                    Surface(shape = CircleShape, color = Color(0xFF173B3A)) {
                        Text(
                            "${jobs.count { !it.state.isFinished }} EN COLA",
                            modifier = Modifier.padding(horizontal = 11.dp, vertical = 7.dp),
                            color = Mint,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
                if (jobs.isEmpty()) {
                    Text("Tus conversiones aparecerán aquí cuando inicies una.", color = Muted, fontSize = 12.sp)
                } else {
                    jobs.sortedByDescending { it.runAttemptCount }.asReversed().forEach { info ->
                        JobCard(info, onCancel = { workManager.cancelWorkById(info.id) })
                    }
                }
            }

            Text("Motor JE2BE original · Conversión local en el dispositivo", color = Muted, fontSize = 11.sp, modifier = Modifier.align(Alignment.CenterHorizontally))
        }
    }
}

@Composable
private fun HeaderPanel() {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(26.dp))
            .background(Brush.linearGradient(listOf(Color(0xFF153B3B), Color(0xFF102A3B), Color(0xFF17263E))))
            .padding(20.dp)
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(13.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier.size(45.dp).clip(RoundedCornerShape(15.dp)).background(Color(0xFF65F0C1)),
                    contentAlignment = Alignment.Center
                ) { Text("J", color = Ink, fontSize = 27.sp, fontWeight = FontWeight.Black) }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("JE2BE", color = SoftWhite, fontSize = 25.sp, fontWeight = FontWeight.Black, letterSpacing = 1.5.sp)
                    Text("MINECRAFT WORLD CONVERTER", color = Color(0xFFB6D2D2), fontSize = 9.sp, letterSpacing = 1.15.sp)
                }
                Surface(shape = CircleShape, color = Color(0x3328F0B2), border = BorderStroke(1.dp, Color(0x665EF0C0))) {
                    Text("ANDROID", modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp), color = Mint, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                }
            }
            Text("Tus mundos.\nEn el formato que necesitas.", color = SoftWhite, fontSize = 23.sp, lineHeight = 28.sp, fontWeight = FontWeight.Bold)
            Text("Convierte mundos de Minecraft con el motor original de JE2BE.", color = Color(0xFFB6C9D2), fontSize = 12.sp, lineHeight = 17.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                InfoPill("6 formatos")
                InfoPill("Procesamiento local")
                InfoPill("Cola de tareas")
            }
        }
    }
}

@Composable
private fun InfoPill(label: String) {
    Surface(shape = CircleShape, color = Color(0x33101B27), border = BorderStroke(1.dp, Color(0x334C8790))) {
        Text(label, modifier = Modifier.padding(horizontal = 9.dp, vertical = 6.dp), color = Color(0xFFD2E7E8), fontSize = 9.sp)
    }
}

@Composable
private fun SectionHeading(number: String, title: String, subtitle: String) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Box(
            modifier = Modifier.size(30.dp).clip(RoundedCornerShape(10.dp)).background(Color(0xFF173B3A)),
            contentAlignment = Alignment.Center
        ) { Text(number, color = Mint, fontSize = 11.sp, fontWeight = FontWeight.Bold) }
        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(title, color = SoftWhite, fontSize = 17.sp, fontWeight = FontWeight.Bold)
            Text(subtitle, color = Muted, fontSize = 11.sp)
        }
    }
}

@Composable
private fun ModeTile(mode: Mode, selected: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val tileColor = if (selected) Color(0xFF153A38) else Panel
    val stroke = if (selected) Mint else Color(0xFF203746)
    Card(
        modifier = modifier.clickable(onClick = onClick),
        shape = RoundedCornerShape(17.dp),
        colors = CardDefaults.cardColors(containerColor = tileColor),
        border = BorderStroke(if (selected) 1.5.dp else 1.dp, stroke)
    ) {
        Column(Modifier.padding(horizontal = 12.dp, vertical = 13.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                Text(mode.source, color = if (selected) Mint else Muted, fontSize = 9.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                Text("→", color = Aqua, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Text(mode.target, color = if (selected) Mint else Muted, fontSize = 9.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                Spacer(Modifier.weight(1f))
                if (selected) Text("✓", color = Mint, fontSize = 13.sp, fontWeight = FontWeight.Black)
            }
            Text(mode.title, color = SoftWhite, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
        }
    }
}

@Composable
private fun JobCard(info: WorkInfo, onCancel: () -> Unit) {
    val name = info.inputData.getString(ConvertWorker.KEY_INPUT_NAME) ?: "Mundo"
    val modeId = info.inputData.getInt(ConvertWorker.KEY_MODE, 0)
    val label = conversionModes.getOrNull(modeId)?.title ?: "Conversión"
    val percent = info.progress.getInt(ConvertWorker.KEY_PERCENT, if (info.state == WorkInfo.State.SUCCEEDED) 100 else 0).coerceIn(0, 100)
    val stage = info.progress.getString(ConvertWorker.KEY_STAGE) ?: when (info.state) {
        WorkInfo.State.ENQUEUED -> "En espera"
        WorkInfo.State.BLOCKED -> "Esperando turno"
        WorkInfo.State.RUNNING -> "Preparando conversión"
        WorkInfo.State.SUCCEEDED -> "Completado"
        WorkInfo.State.FAILED -> "Error"
        WorkInfo.State.CANCELLED -> "Cancelado"
    }
    val error = info.outputData.getString(ConvertWorker.KEY_ERROR)
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(17.dp),
        colors = CardDefaults.cardColors(containerColor = Panel),
        border = BorderStroke(1.dp, Color(0xFF203746))
    ) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Text(name, color = SoftWhite, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(label, color = Muted, fontSize = 11.sp)
                }
                val stateLabel = when (info.state) {
                    WorkInfo.State.SUCCEEDED -> "LISTO"
                    WorkInfo.State.FAILED -> "ERROR"
                    WorkInfo.State.CANCELLED -> "CANCELADO"
                    WorkInfo.State.RUNNING -> "ACTIVO"
                    else -> "EN COLA"
                }
                Text(stateLabel, color = if (info.state == WorkInfo.State.FAILED) Color(0xFFFF9D91) else Mint, fontSize = 9.sp, fontWeight = FontWeight.Bold)
            }
            LinearProgressIndicator(
                progress = percent / 100f,
                modifier = Modifier.fillMaxWidth().height(6.dp).clip(CircleShape),
                color = Mint,
                trackColor = Color(0xFF263B45)
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("$stage · $percent%", modifier = Modifier.weight(1f), color = Muted, fontSize = 11.sp)
                when (info.state) {
                    WorkInfo.State.RUNNING, WorkInfo.State.ENQUEUED, WorkInfo.State.BLOCKED ->
                        OutlinedButton(onClick = onCancel, shape = RoundedCornerShape(10.dp), border = BorderStroke(1.dp, Color(0xFF526B77))) {
                            Text("Cancelar", fontSize = 11.sp)
                        }
                    WorkInfo.State.SUCCEEDED -> Text("Guardado", color = Mint, fontSize = 11.sp)
                    WorkInfo.State.FAILED -> Text(error ?: "Falló", color = Color(0xFFFF9D91), fontSize = 11.sp, maxLines = 2)
                    WorkInfo.State.CANCELLED -> Text("Cancelada", color = Muted, fontSize = 11.sp)
                }
            }
        }
    }
}

private fun displayName(context: android.content.Context, uri: Uri): String? {
    context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
        if (cursor.moveToFirst()) {
            val index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (index >= 0) return cursor.getString(index)
        }
    }
    return uri.lastPathSegment
}
