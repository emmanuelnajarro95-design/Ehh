package app.je2be.android

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import androidx.documentfile.provider.DocumentFile
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

object WorldStorage {
    fun importInput(
        context: Context,
        uri: Uri,
        isTree: Boolean,
        displayName: String,
        mode: Int,
        destination: File,
        progress: (String, Int) -> Unit,
        cancelled: () -> Boolean
    ): File {
        destination.mkdirs()
        val copied = File(destination, "source")
        if (isTree) {
            val tree = DocumentFile.fromTreeUri(context, uri)
                ?: throw IllegalArgumentException("No se pudo abrir la carpeta seleccionada.")
            copyDocumentTree(context, tree, copied, progress, cancelled)
        } else {
            val target = File(destination, safeName(displayName.ifBlank { "world-input" }))
            copyDocumentFile(context, uri, target, progress, cancelled)
            if (mode == 2 || mode == 3) return target
            if (mode == 4 || mode == 5) {
                copied.mkdirs()
                val ps3SaveFile = File(copied, "GAMEDATA")
                if (target.canonicalFile != ps3SaveFile.canonicalFile) {
                    target.copyTo(ps3SaveFile, overwrite = true)
                }
                return copied
            }
            extractZip(target, copied, progress, cancelled)
        }

        if (mode == 4 || mode == 5) return copied
        return findWorldDirectory(copied)
    }

    private fun copyDocumentTree(
        context: Context,
        node: DocumentFile,
        target: File,
        progress: (String, Int) -> Unit,
        cancelled: () -> Boolean
    ) {
        if (cancelled()) throw InterruptedException("Conversión cancelada.")
        if (!node.isDirectory) {
            copyDocumentFile(context, node.uri, target, progress, cancelled)
            return
        }
        if (!target.exists() && !target.mkdirs()) throw IllegalStateException("No se pudo crear ${target.name}.")
        val children = node.listFiles()
        for ((index, child) in children.withIndex()) {
            if (cancelled()) throw InterruptedException("Conversión cancelada.")
            val childName = safeName(child.name ?: "item-$index")
            copyDocumentTree(context, child, File(target, childName), progress, cancelled)
            progress("Copiando mundo", ((index + 1) * 100 / children.size.coerceAtLeast(1)))
        }
    }

    private fun copyDocumentFile(
        context: Context,
        uri: Uri,
        target: File,
        progress: (String, Int) -> Unit,
        cancelled: () -> Boolean
    ) {
        target.parentFile?.mkdirs()
        val input = context.contentResolver.openInputStream(uri)
            ?: throw IllegalStateException("Android no pudo abrir el archivo seleccionado.")
        input.use { source ->
            BufferedInputStream(source).use { buffered ->
                FileOutputStream(target).use { output ->
                    val buffer = ByteArray(128 * 1024)
                    var read: Int
                    var total = 0L
                    while (buffered.read(buffer).also { read = it } >= 0) {
                        if (cancelled()) throw InterruptedException("Conversión cancelada.")
                        if (read == 0) continue
                        output.write(buffer, 0, read)
                        total += read
                        if (total % (1024 * 1024) < buffer.size) progress("Copiando archivo", -1)
                    }
                    output.fd.sync()
                }
            }
        }
    }

    private fun extractZip(
        archive: File,
        destination: File,
        progress: (String, Int) -> Unit,
        cancelled: () -> Boolean
    ) {
        destination.mkdirs()
        val root = destination.canonicalFile
        ZipInputStream(BufferedInputStream(FileInputStream(archive))).use { zip ->
            val buffer = ByteArray(128 * 1024)
            var count = 0
            while (true) {
                if (cancelled()) throw InterruptedException("Conversión cancelada.")
                val entry = zip.nextEntry ?: break
                val normalizedEntryName = entry.name.replace('\\', '/')
                if (normalizedEntryName.startsWith('/') || normalizedEntryName.startsWith("~") ||
                    Regex("^[A-Za-z]:").containsMatchIn(normalizedEntryName)) {
                    throw IllegalArgumentException("El ZIP contiene una ruta no permitida.")
                }
                val output = File(root, normalizedEntryName).canonicalFile
                if (output != root && !output.path.startsWith(root.path + File.separator)) {
                    throw IllegalArgumentException("El ZIP contiene una ruta no permitida.")
                }
                if (entry.isDirectory) {
                    output.mkdirs()
                } else {
                    output.parentFile?.mkdirs()
                    FileOutputStream(output).use { stream ->
                        var read: Int
                        while (zip.read(buffer).also { read = it } >= 0) {
                            if (cancelled()) throw InterruptedException("Conversión cancelada.")
                            if (read > 0) stream.write(buffer, 0, read)
                        }
                    }
                }
                zip.closeEntry()
                count++
                if (count % 20 == 0) progress("Descomprimiendo mundo", -1)
            }
        }
    }

    private fun findWorldDirectory(root: File): File {
        if (!root.isDirectory) throw IllegalArgumentException("La entrada no es una carpeta de mundo.")
        val levelFiles = root.walkTopDown()
            .filter { it.isFile && it.name == "level.dat" }
            .toList()
        return when (levelFiles.size) {
            1 -> levelFiles.single().parentFile
                ?: throw IllegalArgumentException("No se pudo localizar la carpeta del mundo.")
            0 -> throw IllegalArgumentException("No se encontró level.dat. Selecciona la carpeta del mundo o su ZIP.")
            else -> throw IllegalArgumentException("El archivo contiene varios mundos. Selecciona uno solo.")
        }
    }

    fun exportWorld(
        context: Context,
        outputTreeUri: Uri,
        worldDirectory: File,
        worldName: String,
        extension: String,
        cancelled: () -> Boolean
    ): String {
        val tree = DocumentFile.fromTreeUri(context, outputTreeUri)
            ?: throw IllegalArgumentException("No se puede abrir la carpeta de destino.")
        val safeBase = safeName(worldName.substringBeforeLast('.', worldName)).ifBlank { "Converted World" }
        var fileName = "$safeBase$extension"
        var suffix = 2
        while (tree.findFile(fileName) != null) {
            fileName = "$safeBase ($suffix)$extension"
            suffix++
        }
        val archive = File(context.cacheDir, "${System.nanoTime()}$extension")
        try {
            zipDirectory(worldDirectory, archive, cancelled)
            val output = tree.createFile("application/zip", fileName)
                ?: throw IllegalStateException("No se pudo crear el archivo de salida.")
            try {
                FileInputStream(archive).use { input ->
                    context.contentResolver.openOutputStream(output.uri, "w").use { stream ->
                        if (stream == null) throw IllegalStateException("No se pudo escribir en la carpeta de destino.")
                        val buffer = ByteArray(128 * 1024)
                        while (true) {
                            if (cancelled()) throw InterruptedException("Conversión cancelada.")
                            val read = input.read(buffer)
                            if (read < 0) break
                            if (read > 0) stream.write(buffer, 0, read)
                        }
                        stream.flush()
                    }
                }
            } catch (e: Exception) {
                output.delete()
                throw e
            }
            return fileName
        } finally {
            archive.delete()
        }
    }

    private fun zipDirectory(source: File, archive: File, cancelled: () -> Boolean) {
        val root = source.canonicalFile
        ZipOutputStream(BufferedOutputStream(FileOutputStream(archive))).use { zip ->
            zip.setLevel(1)
            val files = root.walkTopDown().filter { it.isFile }.toList()
            val buffer = ByteArray(128 * 1024)
            for (file in files) {
                if (cancelled()) throw InterruptedException("Conversión cancelada.")
                val relative = file.relativeTo(root).invariantSeparatorsPath
                zip.putNextEntry(ZipEntry(relative))
                FileInputStream(file).use { input ->
                    var read: Int
                    while (input.read(buffer).also { read = it } >= 0) {
                        if (cancelled()) throw InterruptedException("Conversión cancelada.")
                        if (read > 0) zip.write(buffer, 0, read)
                    }
                }
                zip.closeEntry()
            }
        }
    }

    private fun safeName(value: String): String {
        val trimmed = value.replace('/', '_').replace('\\', '_').trim().take(120)
        return trimmed.ifBlank { "world" }
    }
}
