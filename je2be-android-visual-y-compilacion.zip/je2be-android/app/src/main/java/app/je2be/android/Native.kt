package app.je2be.android

object Native {
    init {
        System.loadLibrary("je2be_jni")
    }

    fun interface ProgressListener {
        fun onProgress(stage: String, progress: Double, count: Double): Boolean
    }

    external fun newJob(): Long
    external fun cancel(job: Long)
    external fun freeJob(job: Long)
    external fun convert(
        job: Long,
        mode: Int,
        input: String,
        output: String,
        tempRoot: String,
        concurrency: Int,
        listener: ProgressListener
    ): String?
}
