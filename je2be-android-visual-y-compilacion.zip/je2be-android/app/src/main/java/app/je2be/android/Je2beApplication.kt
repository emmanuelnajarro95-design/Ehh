package app.je2be.android

import android.app.Application
import androidx.work.Configuration
import java.util.concurrent.Executors

class Je2beApplication : Application(), Configuration.Provider {
    override val workManagerConfiguration: Configuration
        get() = Configuration.Builder()
            .setExecutor(Executors.newFixedThreadPool(2))
            .build()
}
