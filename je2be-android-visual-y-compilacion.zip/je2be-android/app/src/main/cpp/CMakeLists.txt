cmake_minimum_required(VERSION 3.22.1)
project(je2be_android LANGUAGES C CXX)

set(CMAKE_CXX_STANDARD 20)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_CXX_EXTENSIONS OFF)
set(CMAKE_POSITION_INDEPENDENT_CODE ON)

include(FetchContent)
if(POLICY CMP0169)
    cmake_policy(SET CMP0169 OLD)
endif()
find_package(Python3 REQUIRED COMPONENTS Interpreter)

set(CPM_SOURCE_CACHE "${CMAKE_BINARY_DIR}/cpm-cache" CACHE PATH "CPM package cache" FORCE)
set(CPM_USE_NAMED_CACHE_DIRECTORIES OFF CACHE BOOL "Use flat CPM package cache" FORCE)

FetchContent_Declare(
    je2be_core
    GIT_REPOSITORY https://github.com/kbinani/je2be-core.git
    GIT_TAG 8dfc4de1ba5c7f72e804abea8663380c0dbd5680
    GIT_SHALLOW FALSE
)
FetchContent_GetProperties(je2be_core)
if(NOT je2be_core_POPULATED)
    FetchContent_Populate(je2be_core)
endif()

execute_process(
    COMMAND git -C "${je2be_core_SOURCE_DIR}" rev-parse HEAD
    RESULT_VARIABLE _core_git_result
    OUTPUT_VARIABLE _core_git_sha
    OUTPUT_STRIP_TRAILING_WHITESPACE
    ERROR_QUIET
)
if(NOT _core_git_result EQUAL 0 OR NOT _core_git_sha STREQUAL "8dfc4de1ba5c7f72e804abea8663380c0dbd5680")
    message(FATAL_ERROR "JE2BE Core revision mismatch: expected the same core revision used by je2be-web (8dfc4de1ba5c7f72e804abea8663380c0dbd5680). Found '${_core_git_sha}'.")
endif()

add_subdirectory("${je2be_core_SOURCE_DIR}" "${je2be_core_BINARY_DIR}" EXCLUDE_FROM_ALL)

if(NOT TARGET je2be)
    message(FATAL_ERROR "No se creó el target je2be del motor original.")
endif()

get_target_property(_je2be_libs je2be INTERFACE_LINK_LIBRARIES)
if(_je2be_libs)
    list(REMOVE_ITEM _je2be_libs pthread)
    set_property(TARGET je2be PROPERTY INTERFACE_LINK_LIBRARIES "${_je2be_libs}")
endif()

file(GLOB_RECURSE _gz_streams
    "${CPM_SOURCE_CACHE}/libminecraft-file/include/mcfile/stream/gz-file-input-stream.hpp"
    "${CPM_SOURCE_CACHE}/libminecraft-file/*/include/mcfile/stream/gz-file-input-stream.hpp")
if(NOT _gz_streams)
    message(FATAL_ERROR "No se encontró el flujo gzip de libminecraft-file en el caché CPM.")
endif()
execute_process(
    COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_LIST_DIR}/../../../../patches/fix_gzread.py" ${_gz_streams}
    RESULT_VARIABLE _patch_result
    COMMAND_ECHO STDOUT
)
if(NOT _patch_result EQUAL 0)
    message(FATAL_ERROR "No se pudo aplicar el ajuste Android de gzread.")
endif()

add_library(je2be_jni SHARED bridge.cpp)
target_compile_options(je2be_jni PRIVATE -Wall -Wextra -Wno-unused-parameter)
target_link_libraries(je2be_jni PRIVATE je2be log)
