#include <jni.h>

#include <algorithm>
#include <atomic>
#include <filesystem>
#include <memory>
#include <mutex>
#include <optional>
#include <sstream>
#include <stdexcept>
#include <string>

#include <je2be.hpp>

namespace fs = std::filesystem;

namespace {
JavaVM *gVm = nullptr;

struct NativeJob {
    std::atomic_bool cancelled{false};
};

bool acquireEnv(JNIEnv **env, bool &attached) {
    attached = false;
    if (!gVm) return false;
    if (gVm->GetEnv(reinterpret_cast<void **>(env), JNI_VERSION_1_6) == JNI_OK) return true;
#if defined(__ANDROID__)
    if (gVm->AttachCurrentThread(env, nullptr) != JNI_OK) return false;
#else
    if (gVm->AttachCurrentThread(reinterpret_cast<void **>(env), nullptr) != JNI_OK) return false;
#endif
    attached = true;
    return true;
}

std::string fromJava(JNIEnv *env, jstring value) {
    if (!value) return {};
    const char *chars = env->GetStringUTFChars(value, nullptr);
    if (!chars) throw std::runtime_error("No se pudo leer una ruta Android.");
    std::string result(chars);
    env->ReleaseStringUTFChars(value, chars);
    return result;
}

class ProgressBridge final : public je2be::java::Progress,
                             public je2be::bedrock::Progress,
                             public je2be::lce::Progress {
public:
    ProgressBridge(JNIEnv *env, jobject listener, NativeJob *job)
        : job_(job) {
        if (!listener) return;
        listener_ = env->NewGlobalRef(listener);
        jclass type = env->GetObjectClass(listener);
        callback_ = env->GetMethodID(type, "onProgress", "(Ljava/lang/String;DD)Z");
        env->DeleteLocalRef(type);
    }

    ~ProgressBridge() override {
        if (!listener_) return;
        JNIEnv *env = nullptr;
        bool attached = false;
        if (acquireEnv(&env, attached)) {
            env->DeleteGlobalRef(listener_);
            if (attached) gVm->DetachCurrentThread();
        }
    }

    bool reportConvert(je2be::Rational<je2be::u64> const &p, je2be::u64 chunks) override {
        return send("Convirtiendo chunks", p.toD(), static_cast<double>(chunks));
    }

    bool reportEntityPostProcess(je2be::Rational<je2be::u64> const &p) override {
        return send("Procesando entidades", p.toD(), 0.0);
    }

    bool reportCompaction(je2be::Rational<je2be::u64> const &p) override {
        return send("Optimizando mundo", p.toD(), 0.0);
    }

    bool reportTerraform(je2be::Rational<je2be::u64> const &p, je2be::u64 chunks) override {
        return send("Ajustando terreno", p.toD(), static_cast<double>(chunks));
    }

    bool report(je2be::Rational<je2be::u64> const &p) override {
        return send("Leyendo mundo de consola", p.toD(), 0.0);
    }

private:
    bool send(char const *stage, double progress, double count) {
        if (!job_ || job_->cancelled.load()) return false;
        if (!listener_ || !callback_) return true;
        std::lock_guard<std::mutex> lock(callbackMutex_);
        JNIEnv *env = nullptr;
        bool attached = false;
        if (!acquireEnv(&env, attached)) return true;
        jstring text = env->NewStringUTF(stage);
        jboolean keepGoing = JNI_TRUE;
        if (text) {
            keepGoing = env->CallBooleanMethod(listener_, callback_, text,
                                                static_cast<jdouble>(progress),
                                                static_cast<jdouble>(count));
            env->DeleteLocalRef(text);
        }
        if (env->ExceptionCheck()) {
            env->ExceptionClear();
            keepGoing = JNI_FALSE;
        }
        if (attached) gVm->DetachCurrentThread();
        if (keepGoing != JNI_TRUE) job_->cancelled.store(true);
        return keepGoing == JNI_TRUE && !job_->cancelled.load();
    }

    NativeJob *job_ = nullptr;
    jobject listener_ = nullptr;
    jmethodID callback_ = nullptr;
    std::mutex callbackMutex_;
};

std::string statusMessage(je2be::Status const &status) {
    auto error = status.error();
    if (!error) return {};
    std::ostringstream out;
    out << (error->fWhat.empty() ? "JE2BE no pudo convertir este mundo." : error->fWhat);
    for (auto it = error->fTrace.rbegin(); it != error->fTrace.rend(); ++it) {
        out << "\n" << it->fFile << ':' << it->fLine;
    }
    return out.str();
}

std::optional<fs::path> makeTemp(fs::path const &root) {
    return mcfile::File::CreateTempDir(root);
}

void removeTemp(std::optional<fs::path> const &path) {
    if (path && fs::exists(*path)) je2be::Fs::DeleteAll(*path);
}

je2be::Status javaToBedrock(fs::path const &input, fs::path const &output,
                            fs::path const &scratch, int concurrency,
                            ProgressBridge &progress, NativeJob *job) {
    if (job->cancelled.load()) return je2be::Status::Error(__FILE__, __LINE__, "Conversión cancelada.");
    auto temp = makeTemp(scratch);
    auto dbTemp = makeTemp(scratch);
    if (!temp || !dbTemp) return je2be::Status::Error(__FILE__, __LINE__, "No se pudieron crear los temporales de JE2BE.");
    je2be::java::Options options;
    options.fLevelDirectoryStructure = je2be::LevelDirectoryStructure::Vanilla;
    options.fTempDirectory = *temp;
    options.fDbTempDirectory = *dbTemp;
    auto result = je2be::java::Converter::Run(input, output, options, std::max(1, concurrency), &progress);
    removeTemp(temp);
    removeTemp(dbTemp);
    return result;
}

je2be::Status runConversion(int mode, fs::path const &input, fs::path const &output,
                            fs::path const &scratch, int concurrency,
                            ProgressBridge &progress, NativeJob *job) {
    std::error_code ec;
    fs::create_directories(scratch, ec);
    if (ec) return je2be::Status::Error(__FILE__, __LINE__, "No se pudo crear la carpeta temporal: " + ec.message());
    fs::create_directories(output, ec);
    if (ec) return je2be::Status::Error(__FILE__, __LINE__, "No se pudo crear la carpeta de salida: " + ec.message());

    switch (mode) {
    case 0:
        if (!fs::is_directory(input)) return je2be::Status::Error(__FILE__, __LINE__, "La entrada Java debe ser una carpeta de mundo.");
        return javaToBedrock(input, output, scratch, concurrency, progress, job);

    case 1: {
        if (!fs::is_directory(input)) return je2be::Status::Error(__FILE__, __LINE__, "La entrada Bedrock debe ser una carpeta de mundo.");
        auto temp = makeTemp(scratch);
        if (!temp) return je2be::Status::Error(__FILE__, __LINE__, "No se pudo crear la carpeta temporal de JE2BE.");
        je2be::bedrock::Options options;
        options.fTempDirectory = *temp;
        auto result = je2be::bedrock::Converter::Run(input, output, options,
                                                     static_cast<unsigned>(std::max(1, concurrency)), &progress);
        removeTemp(temp);
        return result;
    }

    case 2:
    case 3:
    case 4:
    case 5: {
        bool const xbox = mode == 2 || mode == 3;
        bool const toBedrock = mode == 3 || mode == 5;
        if (xbox && !fs::is_regular_file(input)) return je2be::Status::Error(__FILE__, __LINE__, "Selecciona el archivo SAVE.BIN de Xbox 360.");
        if (!xbox && !fs::is_directory(input)) return je2be::Status::Error(__FILE__, __LINE__, "Selecciona la carpeta de guardado de PS3.");

        fs::path javaOutput = output;
        if (toBedrock) {
            javaOutput = scratch / "java-intermediate";
            fs::create_directories(javaOutput, ec);
            if (ec) return je2be::Status::Error(__FILE__, __LINE__, "No se pudo crear el mundo intermedio.");
        }

        auto temp = makeTemp(scratch);
        if (!temp) return je2be::Status::Error(__FILE__, __LINE__, "No se pudo crear la carpeta temporal de JE2BE.");
        je2be::lce::Options options;
        options.fTempDirectory = *temp;
        je2be::Status result = xbox
            ? je2be::xbox360::Converter::Run(input, javaOutput, static_cast<unsigned>(std::max(1, concurrency)), options, &progress)
            : je2be::ps3::Converter::Run(input, javaOutput, static_cast<unsigned>(std::max(1, concurrency)), options, &progress);
        removeTemp(temp);
        if (!result.ok() || !toBedrock || job->cancelled.load()) return result;
        return javaToBedrock(javaOutput, output, scratch, concurrency, progress, job);
    }

    default:
        return je2be::Status::Error(__FILE__, __LINE__, "Modo de conversión desconocido.");
    }
}

} // namespace

extern "C" JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM *vm, void *) {
    gVm = vm;
    return JNI_VERSION_1_6;
}

extern "C" JNIEXPORT jlong JNICALL
Java_app_je2be_android_Native_newJob(JNIEnv *, jobject) {
    return reinterpret_cast<jlong>(new NativeJob());
}

extern "C" JNIEXPORT void JNICALL
Java_app_je2be_android_Native_cancel(JNIEnv *, jobject, jlong handle) {
    auto *job = reinterpret_cast<NativeJob *>(handle);
    if (job) job->cancelled.store(true);
}

extern "C" JNIEXPORT void JNICALL
Java_app_je2be_android_Native_freeJob(JNIEnv *, jobject, jlong handle) {
    delete reinterpret_cast<NativeJob *>(handle);
}

extern "C" JNIEXPORT jstring JNICALL
Java_app_je2be_android_Native_convert(JNIEnv *env, jobject, jlong handle, jint mode,
                                       jstring input, jstring output, jstring tempRoot,
                                       jint concurrency, jobject listener) {
    auto *job = reinterpret_cast<NativeJob *>(handle);
    if (!job || !input || !output || !tempRoot) return env->NewStringUTF("Parámetros de conversión no válidos.");
    try {
        fs::path inputPath(fromJava(env, input));
        fs::path outputPath(fromJava(env, output));
        fs::path scratchPath(fromJava(env, tempRoot));
        ProgressBridge progress(env, listener, job);
        auto status = runConversion(mode, inputPath, outputPath, scratchPath,
                                    static_cast<int>(concurrency), progress, job);
        std::string message = statusMessage(status);
        if (job->cancelled.load() && message.empty()) message = "Conversión cancelada.";
        return message.empty() ? nullptr : env->NewStringUTF(message.c_str());
    } catch (std::exception const &e) {
        return env->NewStringUTF(e.what());
    } catch (...) {
        return env->NewStringUTF("Error nativo inesperado durante la conversión.");
    }
}
