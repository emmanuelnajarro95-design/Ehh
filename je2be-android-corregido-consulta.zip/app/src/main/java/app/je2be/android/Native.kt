package app.je2be.android

interface ProgressListener {
    fun onProgress(stage: String, done: Double, total: Double)
}

object Native {
    init {
        System.loadLibrary("je2be_jni")
    }

    external fun newJob(): Long
    external fun freeJob(handle: Long)
    external fun cancel(handle: Long)

    /** Returns null on success, otherwise a human-readable error. */
    external fun convert(
        handle: Long,
        toBedrock: Boolean,
        input: String,
        output: String,
        tempRoot: String,
        listener: ProgressListener,
        concurrency: Int
    ): String?
}
