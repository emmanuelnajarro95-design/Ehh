package app.je2be.android.resourcepacks

import java.io.File
import java.util.UUID

/**
 * Converts the common PNG texture subset between Java and Bedrock pack layouts.
 * This does not translate Java models, predicates, shaders, fonts, sounds,
 * animations or Bedrock geometry/render controllers.
 */
object ResourcePackConverter {
    data class Result(
        val convertedPacks: Int,
        val convertedPngTextures: Int,
        val report: String
    )

    fun convertEmbeddedPacks(javaToBedrock: Boolean, inputWorld: File, outputWorld: File): Result {
        val candidates = if (javaToBedrock) findJavaPackDirectories(inputWorld) else findBedrockPackDirectories(inputWorld)
        if (candidates.isEmpty()) {
            return Result(0, 0, "No se encontraron paquetes de recursos integrados en el mundo de origen.")
        }

        val messages = mutableListOf<String>()
        var packCount = 0
        var textureCount = 0
        val bedrockWorldEntries = mutableListOf<String>()
        val usedNames = mutableSetOf<String>()

        for (source in candidates) {
            val baseName = safeName(source.name.ifBlank { "resource-pack" })
            var name = baseName
            var suffix = 2
            while (!usedNames.add(name)) name = "${baseName.take(56)}-$suffix".also { suffix++ }
            val destination = if (javaToBedrock) {
                File(outputWorld, "resource_packs/$name")
            } else {
                File(outputWorld, "converted-resource-packs/$name")
            }
            destination.deleteRecursively()
            destination.mkdirs()

            val converted = if (javaToBedrock) {
                convertJavaPack(source, destination)
            } else {
                convertBedrockPack(source, destination)
            }
            packCount++
            textureCount += converted.first
            messages += "$name: ${converted.first} texturas PNG trasladadas; ${converted.second} archivos no traducidos."

            if (javaToBedrock) {
                bedrockWorldEntries += """{"pack_id":"${converted.third}","version":[1,0,0]}"""
            }
        }

        if (javaToBedrock && bedrockWorldEntries.isNotEmpty()) {
            File(outputWorld, "world_resource_packs.json").writeText(
                bedrockWorldEntries.joinToString(prefix = "[\n", postfix = "\n]\n", separator = ",\n")
            )
        }

        val heading = if (javaToBedrock) "Java → Bedrock" else "Bedrock → Java"
        val limitation = """
            |Alcance: se trasladaron las texturas PNG comunes de bloques y objetos y se generó la estructura básica del paquete.
            |No se traducen automáticamente modelos 3D, blockstates, predicates, shaders, fuentes, sonidos, animaciones,
            |geometría de entidades, render controllers ni referencias personalizadas. Revisa el paquete en Minecraft.
            |En Bedrock → Java los paquetes quedan en converted-resource-packs; Minecraft Java no los activa automáticamente desde el mundo.
        """.trimMargin()
        val report = "$heading\n\n${messages.joinToString("\n")}\n\n$limitation"
        File(outputWorld, "JE2BE-RESOURCE-PACKS-REPORT.txt").writeText(report)
        return Result(packCount, textureCount, report)
    }

    private fun findJavaPackDirectories(world: File): List<File> {
        val roots = listOf(File(world, "resourcepacks"), File(world, "resource_packs"), File(world, "resources"))
        return roots.filter { it.isDirectory }.flatMap { root ->
            root.listFiles()?.filter { it.isDirectory && File(it, "pack.mcmeta").isFile }.orEmpty()
                .ifEmpty { if (File(root, "pack.mcmeta").isFile) listOf(root) else emptyList() }
        }.distinctBy { it.canonicalPath }
    }

    private fun findBedrockPackDirectories(world: File): List<File> {
        val root = File(world, "resource_packs")
        if (!root.isDirectory) return emptyList()
        return root.listFiles()?.filter { it.isDirectory && File(it, "manifest.json").isFile }.orEmpty()
    }

    /** Returns texture count, unsupported-file count and generated Bedrock pack UUID. */
    private fun convertJavaPack(source: File, destination: File): Triple<Int, Int, String> {
        val blockAtlas = linkedMapOf<String, String>()
        val itemAtlas = linkedMapOf<String, String>()
        var textures = 0
        var unsupported = 0
        val textureRoot = File(source, "assets")
        if (textureRoot.isDirectory) {
            textureRoot.walkTopDown().filter { it.isFile }.forEach { file ->
                val relative = file.relativeTo(textureRoot).invariantSeparatorsPath
                if (!relative.endsWith(".png", ignoreCase = true)) {
                    unsupported++
                    return@forEach
                }
                val parts = relative.split('/')
                if (parts.size < 4 || parts[1] != "textures") {
                    unsupported++
                    return@forEach
                }
                val category = parts[2]
                val subPath = parts.drop(3).joinToString("/")
                val targetCategory = when (category) {
                    "block", "blocks" -> "blocks"
                    "item", "items" -> "items"
                    else -> category
                }
                val namespace = parts[0]
                val targetRelative = if (namespace == "minecraft") subPath else "$namespace/$subPath"
                val target = File(destination, "textures/$targetCategory/$targetRelative")
                target.parentFile?.mkdirs()
                file.copyTo(target, overwrite = true)
                if (targetCategory == "blocks" || targetCategory == "items") {
                    textures++
                    val key = targetRelative.removeSuffix(".png").replace('/', '_')
                        .replace(Regex("[^A-Za-z0-9_.-]"), "_")
                    val textureRef = "textures/$targetCategory/${targetRelative.removeSuffix(".png")}"
                    if (targetCategory == "blocks") blockAtlas[key] = textureRef
                    if (targetCategory == "items") itemAtlas[key] = textureRef
                } else {
                    unsupported++
                }
            }
        } else {
            unsupported++
        }

        val packUuid = UUID.randomUUID().toString()
        val moduleUuid = UUID.randomUUID().toString()
        val packName = source.name
        File(destination, "manifest.json").writeText(
            """{
              "format_version": 2,
              "header": {
                "name": ${jsonString(packName)},
                "description": ${jsonString("Converted from a Java resource pack by JE2BE Android")},
                "uuid": ${jsonString(packUuid)},
                "version": [1, 0, 0],
                "min_engine_version": [1, 20, 0]
              },
              "modules": [{
                "type": "resources",
                "uuid": ${jsonString(moduleUuid)},
                "version": [1, 0, 0]
              }]
            }""".trimIndent()
        )
        writeAtlas(File(destination, "textures/terrain_texture.json"), "atlas.terrain", blockAtlas)
        writeAtlas(File(destination, "textures/item_texture.json"), "atlas.items", itemAtlas)
        File(source, "pack.png").takeIf { it.isFile }?.copyTo(File(destination, "pack_icon.png"), overwrite = true)
        copyTextMetadata(source, destination)
        return Triple(textures, unsupported, packUuid)
    }

    private fun convertBedrockPack(source: File, destination: File): Triple<Int, Int, String> {
        var textures = 0
        var unsupported = 0
        val textureRoot = File(source, "textures")
        if (textureRoot.isDirectory) {
            textureRoot.walkTopDown().filter { it.isFile }.forEach { file ->
                val relative = file.relativeTo(textureRoot).invariantSeparatorsPath
                if (!relative.endsWith(".png", ignoreCase = true)) {
                    unsupported++
                    return@forEach
                }
                val parts = relative.split('/')
                val category = parts.firstOrNull().orEmpty()
                val javaCategory = when (category) {
                    "blocks", "block" -> "block"
                    "items", "item" -> "item"
                    else -> category
                }
                val suffix = parts.drop(1).joinToString("/")
                if (suffix.isBlank()) {
                    unsupported++
                    return@forEach
                }
                val target = File(destination, "assets/minecraft/textures/$javaCategory/$suffix")
                target.parentFile?.mkdirs()
                file.copyTo(target, overwrite = true)
                if (javaCategory == "block" || javaCategory == "item") {
                    textures++
                } else {
                    unsupported++
                }
            }
        }

        File(destination, "pack.mcmeta").writeText(
            """{
              "pack": {
                "pack_format": 34,
                "description": ${jsonString("${source.name} - converted from Bedrock by JE2BE Android")}
              }
            }""".trimIndent()
        )
        File(source, "pack_icon.png").takeIf { it.isFile }?.copyTo(File(destination, "pack.png"), overwrite = true)
        copyTextMetadata(source, destination)
        return Triple(textures, unsupported, "")
    }

    private fun writeAtlas(file: File, atlasName: String, entries: Map<String, String>) {
        file.parentFile?.mkdirs()
        val jsonEntries = entries.entries.joinToString(",\n") { (key, path) ->
            "    ${jsonString(key)}: { \"textures\": ${jsonString(path)} }"
        }
        file.writeText(
            """{
              "resource_pack_name": "je2be-converted",
              "texture_name": "$atlasName",
              "texture_data": {
            ${jsonEntries}
              }
            }""".trimIndent()
        )
    }

    private fun copyTextMetadata(source: File, destination: File) {
        val texts = File(source, "texts")
        if (texts.isDirectory) {
            texts.copyRecursively(File(destination, "texts"), overwrite = true)
        }
    }

    private fun jsonString(value: String): String = buildString {
        append('"')
        value.forEach { ch ->
            when (ch) {
                '"' -> append("\\\"")
                '\\' -> append("\\\\")
                '\b' -> append("\\b")
                '\u000C' -> append("\\f")
                '\n' -> append("\\n")
                '\r' -> append("\\r")
                '\t' -> append("\\t")
                else -> if (ch.code < 0x20) append("\\u%04x".format(ch.code)) else append(ch)
            }
        }
        append('"')
    }

    private fun safeName(value: String): String =
        value.replace(Regex("[^A-Za-z0-9._-]"), "_").trim('_', '.').take(64).ifBlank { "resource-pack" }
}
