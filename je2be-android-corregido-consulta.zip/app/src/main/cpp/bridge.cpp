#include <jni.h>

#include <algorithm>
#include <atomic>
#include <filesystem>
#include <memory>
#include <sstream>
#include <string>
#include <system_error>

#include <je2be.hpp>

namespace fs = std::filesystem;

namespace {

JavaVM *gVm = nullptr;

jint attachCurrentThread(JNIEnv **env) {
#if defined(__ANDROID__)
  return gVm->AttachCurrentThread(env, nullptr);
#else
  return gVm->AttachCurrentThread(reinterpret_cast<void **>(env), nullptr);
#endif
}

struct NativeJob {
  std::atomic_bool cancelled{false};
};

class JniProgress {
public:
  JniProgress(JNIEnv *env, jobject listener, NativeJob *job) : fJob(job) {
    if (listener) {
      fListener = env->NewGlobalRef(listener);
      jclass cls = env->GetObjectClass(listener);
      fMethod = env->GetMethodID(cls, "onProgress", "(Ljava/lang/String;DD)V");
      env->DeleteLocalRef(cls);
    }
  }

  virtual ~JniProgress() {
    if (fListener && gVm) {
      JNIEnv *env = nullptr;
      bool attached = false;
      if (gVm->GetEnv(reinterpret_cast<void **>(&env), JNI_VERSION_1_6) != JNI_OK) {
        if (attachCurrentThread(&env) == JNI_OK) {
          attached = true;
        }
      }
      if (env) {
        env->DeleteGlobalRef(fListener);
      }
      if (attached) {
        gVm->DetachCurrentThread();
      }
    }
  }

protected:
  bool report(char const *stage, double done, double total) {
    if (fJob->cancelled.load()) {
      return false;
    }
    if (!fListener || !fMethod || !gVm) {
      return !fJob->cancelled.load();
    }

    JNIEnv *env = nullptr;
    bool attached = false;
    if (gVm->GetEnv(reinterpret_cast<void **>(&env), JNI_VERSION_1_6) != JNI_OK) {
      if (attachCurrentThread(&env) != JNI_OK) {
        return !fJob->cancelled.load();
      }
      attached = true;
    }

    jstring text = env->NewStringUTF(stage);
    if (text) {
      env->CallVoidMethod(fListener, fMethod, text,
                          static_cast<jdouble>(done),
                          static_cast<jdouble>(total));
      env->DeleteLocalRef(text);
    }

    bool callbackOk = !env->ExceptionCheck();
    if (!callbackOk) {
      env->ExceptionDescribe();
      env->ExceptionClear();
    }
    if (attached) {
      gVm->DetachCurrentThread();
    }
    return callbackOk && !fJob->cancelled.load();
  }

  NativeJob *fJob;
  jobject fListener = nullptr;
  jmethodID fMethod = nullptr;
};

class JavaProgress final : public JniProgress, public je2be::java::Progress {
public:
  using JniProgress::JniProgress;
  bool reportConvert(je2be::Rational<je2be::u64> const &p, je2be::u64) override {
    return report("Convirtiendo chunks", static_cast<double>(p.fNum), static_cast<double>(p.fDen));
  }
  bool reportEntityPostProcess(je2be::Rational<je2be::u64> const &p) override {
    return report("Procesando entidades", static_cast<double>(p.fNum), static_cast<double>(p.fDen));
  }
  bool reportCompaction(je2be::Rational<je2be::u64> const &p) override {
    return report("Optimizando base de datos", static_cast<double>(p.fNum), static_cast<double>(p.fDen));
  }
};

class BedrockProgress final : public JniProgress, public je2be::bedrock::Progress {
public:
  using JniProgress::JniProgress;
  bool reportConvert(je2be::Rational<je2be::u64> const &p, je2be::u64) override {
    return report("Convirtiendo chunks", static_cast<double>(p.fNum), static_cast<double>(p.fDen));
  }
  bool reportTerraform(je2be::Rational<je2be::u64> const &p, je2be::u64) override {
    return report("Ajustando terreno", static_cast<double>(p.fNum), static_cast<double>(p.fDen));
  }
};

std::string statusMessage(je2be::Status const &status) {
  auto error = status.error();
  if (!error) {
    return {};
  }
  std::ostringstream out;
  out << (error->fWhat.empty() ? "JE2BE no pudo convertir el mundo." : error->fWhat);
  for (auto it = error->fTrace.rbegin(); it != error->fTrace.rend(); ++it) {
    out << "\n  en " << it->fFile << ':' << it->fLine;
  }
  return out.str();
}

} // namespace

extern "C" JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM *vm, void *) {
  gVm = vm;
  return JNI_VERSION_1_6;
}

extern "C" JNIEXPORT jlong JNICALL
Java_app_je2be_android_Native_newJob(JNIEnv *, jobject) {
  return reinterpret_cast<jlong>(new NativeJob());
}

extern "C" JNIEXPORT void JNICALL
Java_app_je2be_android_Native_freeJob(JNIEnv *, jobject, jlong handle) {
  delete reinterpret_cast<NativeJob *>(handle);
}

extern "C" JNIEXPORT void JNICALL
Java_app_je2be_android_Native_cancel(JNIEnv *, jobject, jlong handle) {
  auto *job = reinterpret_cast<NativeJob *>(handle);
  if (job) {
    job->cancelled.store(true);
  }
}

extern "C" JNIEXPORT jstring JNICALL
Java_app_je2be_android_Native_convert(JNIEnv *env, jobject, jlong handle,
                                      jboolean toBedrock, jstring input,
                                      jstring output, jstring tempRoot,
                                      jobject listener, jint concurrency) {
  auto *job = reinterpret_cast<NativeJob *>(handle);
  if (!job || !input || !output || !tempRoot) {
    return env->NewStringUTF("Parámetros de conversión inválidos.");
  }

  const char *inputChars = env->GetStringUTFChars(input, nullptr);
  const char *outputChars = env->GetStringUTFChars(output, nullptr);
  const char *tempChars = env->GetStringUTFChars(tempRoot, nullptr);
  if (!inputChars || !outputChars || !tempChars) {
    if (inputChars) env->ReleaseStringUTFChars(input, inputChars);
    if (outputChars) env->ReleaseStringUTFChars(output, outputChars);
    if (tempChars) env->ReleaseStringUTFChars(tempRoot, tempChars);
    return env->NewStringUTF("No se pudieron leer las rutas de los archivos.");
  }

  fs::path inPath(inputChars);
  fs::path outPath(outputChars);
  fs::path scratch(tempChars);
  env->ReleaseStringUTFChars(input, inputChars);
  env->ReleaseStringUTFChars(output, outputChars);
  env->ReleaseStringUTFChars(tempRoot, tempChars);

  try {
    if (!fs::is_directory(inPath)) {
      return env->NewStringUTF("La entrada no es una carpeta de mundo válida.");
    }
    std::error_code ec;
    fs::create_directories(scratch, ec);
    if (ec) {
      return env->NewStringUTF(("No se pudo preparar el directorio temporal: " + ec.message()).c_str());
    }
    if (fs::exists(outPath)) {
      fs::remove_all(outPath, ec);
      if (ec) {
        return env->NewStringUTF(("No se pudo limpiar la salida temporal: " + ec.message()).c_str());
      }
    }

    je2be::Status status;
    if (toBedrock == JNI_TRUE) {
      je2be::java::Options options;
      options.fTempDirectory = mcfile::File::CreateTempDir(scratch);
      options.fDbTempDirectory = mcfile::File::CreateTempDir(scratch);
      if (!options.fTempDirectory || !options.fDbTempDirectory) {
        return env->NewStringUTF("No se pudieron crear los directorios temporales de JE2BE.");
      }
      JavaProgress progress(env, listener, job);
      status = je2be::java::Converter::Run(
          inPath, outPath, options,
          static_cast<int>(std::max(1, static_cast<int>(concurrency))),
          &progress);
      je2be::Fs::DeleteAll(*options.fTempDirectory);
      je2be::Fs::DeleteAll(*options.fDbTempDirectory);
    } else {
      je2be::bedrock::Options options;
      options.fTempDirectory = mcfile::File::CreateTempDir(scratch);
      if (!options.fTempDirectory) {
        return env->NewStringUTF("No se pudo crear el directorio temporal de JE2BE.");
      }
      BedrockProgress progress(env, listener, job);
      status = je2be::bedrock::Converter::Run(
          inPath, outPath, options,
          static_cast<unsigned>(std::max(1, static_cast<int>(concurrency))),
          &progress);
      je2be::Fs::DeleteAll(*options.fTempDirectory);
    }

    if (job->cancelled.load()) {
      return env->NewStringUTF("Conversión cancelada.");
    }
    std::string message = statusMessage(status);
    if (!message.empty()) {
      return env->NewStringUTF(message.c_str());
    }
    if (!fs::exists(outPath) || fs::is_empty(outPath)) {
      return env->NewStringUTF("JE2BE terminó sin generar archivos de salida.");
    }
    return nullptr;
  } catch (std::exception const &e) {
    return env->NewStringUTF(e.what());
  } catch (...) {
    return env->NewStringUTF("Error nativo desconocido durante la conversión.");
  }
}
