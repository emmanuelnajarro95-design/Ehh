package app.je2be.android.resourcepacks

import java.io.File
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ResourcePackConverterTest {
    @Test
    fun javaTextureFolderCreatesBedrockPackageMetadataAndAtlas() {
        val root = java.nio.file.Files.createTempDirectory("je2be-java-pack-test-").toFile()
        try {
            val world = File(root, "world").apply { mkdirs() }
            val pack = File(world, "resourcepacks/sample")
            val texture = File(pack, "assets/minecraft/textures/block/dirt.png")
            texture.parentFile.mkdirs()
            texture.writeBytes(byteArrayOf(1, 2, 3, 4))
            File(pack, "pack.mcmeta").writeText("{\"pack\":{\"pack_format\":34}}")

            val output = File(root, "bedrock-output").apply { mkdirs() }
            val result = ResourcePackConverter.convertEmbeddedPacks(true, world, output)

            assertEquals(1, result.convertedPacks)
            assertEquals(1, result.convertedPngTextures)
            assertTrue(File(output, "resource_packs/sample/manifest.json").isFile)
            assertTrue(File(output, "resource_packs/sample/textures/blocks/dirt.png").isFile)
            assertTrue(File(output, "resource_packs/sample/textures/terrain_texture.json").readText().contains("dirt"))
            assertTrue(File(output, "world_resource_packs.json").isFile)
        } finally {
            root.deleteRecursively()
        }
    }

    @Test
    fun bedrockTextureFolderCreatesJavaPackLayout() {
        val root = java.nio.file.Files.createTempDirectory("je2be-bedrock-pack-test-").toFile()
        try {
            val world = File(root, "world").apply { mkdirs() }
            val pack = File(world, "resource_packs/sample")
            val texture = File(pack, "textures/blocks/stone.png")
            texture.parentFile.mkdirs()
            texture.writeBytes(byteArrayOf(9, 8, 7))
            File(pack, "manifest.json").writeText("{}")

            val output = File(root, "java-output").apply { mkdirs() }
            val result = ResourcePackConverter.convertEmbeddedPacks(false, world, output)

            assertEquals(1, result.convertedPacks)
            assertEquals(1, result.convertedPngTextures)
            assertTrue(File(output, "converted-resource-packs/sample/pack.mcmeta").isFile)
            assertTrue(File(output, "converted-resource-packs/sample/assets/minecraft/textures/block/stone.png").isFile)
            assertTrue(File(output, "JE2BE-RESOURCE-PACKS-REPORT.txt").isFile)
        } finally {
            root.deleteRecursively()
        }
    }
}
