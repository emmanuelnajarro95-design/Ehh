package app.je2be.android

import android.Manifest
import android.app.ActivityManager
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.documentfile.provider.DocumentFile
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkInfo
import androidx.work.WorkManager
import androidx.work.getWorkInfosByTagFlow
import androidx.work.workDataOf
import kotlinx.coroutines.launch
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 100)
        }
        setContent { MaterialTheme { JE2BEScreen() } }
    }
}

private data class SourceSelection(val uri: Uri, val isTree: Boolean, val name: String)

@Composable
private fun JE2BEScreen() {
    val context = LocalContext.current
    val workManager = remember { WorkManager.getInstance(context) }
    val scope = rememberCoroutineScope()
    val pending = remember { mutableStateListOf<SourceSelection>() }
    var outputUri by remember { mutableStateOf<Uri?>(null) }
    var toBedrock by remember { mutableStateOf(true) }
    var concurrency by remember { mutableIntStateOf(defaultConcurrency(context)) }
    var statusText by remember { mutableStateOf<String?>(null) }
    val jobs by workManager.getWorkInfosByTagFlow(ConvertWorker.TAG_CONVERSION)
        .collectAsState(initial = emptyList())

    val pickWorldFolder = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            takeReadPermission(context, uri)
            val name = DocumentFile.fromTreeUri(context, uri)?.name ?: "Mundo"
            if (pending.none { it.uri == uri }) pending.add(SourceSelection(uri, true, name))
            statusText = null
        }
    }
    val pickWorldArchive = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            takeReadPermission(context, uri)
            val name = queryDisplayName(context, uri) ?: "mundo.zip"
            if (pending.none { it.uri == uri }) pending.add(SourceSelection(uri, false, name))
            statusText = null
        }
    }
    val pickOutput = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            try {
                context.contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                )
            } catch (_: SecurityException) {
                statusText = "No se pudieron conservar los permisos de la carpeta de salida."
                return@rememberLauncherForActivityResult
            }
            outputUri = uri
        }
    }

    val laneCount = concurrency.coerceIn(1, 4)
    Surface(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier.statusBarsPadding().padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("JE2BE Android", style = MaterialTheme.typography.headlineMedium)
            Text(
                "Conversor local de mundos Minecraft Java y Bedrock",
                style = MaterialTheme.typography.bodyMedium
            )

            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Dirección de conversión", style = MaterialTheme.typography.titleMedium)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(selected = toBedrock, onClick = { toBedrock = true }, label = { Text("Java → Bedrock") })
                        FilterChip(selected = !toBedrock, onClick = { toBedrock = false }, label = { Text("Bedrock → Java") })
                    }
                }
            }

            Text("Mundos pendientes", style = MaterialTheme.typography.titleMedium)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { pickWorldFolder.launch(null) }) { Text("Elegir carpeta") }
                OutlinedButton(onClick = { pickWorldArchive.launch(arrayOf("application/zip", "application/octet-stream", "application/x-zip-compressed")) }) {
                    Text("Elegir ZIP / mcworld")
                }
            }
            if (pending.isEmpty()) {
                Text("Todavía no has añadido mundos.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            } else {
                pending.forEachIndexed { index, source ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("${index + 1}. ${source.name}", modifier = Modifier.weight(1f))
                        OutlinedButton(onClick = { pending.remove(source) }) { Text("Quitar") }
                    }
                }
            }

            Text("Carpeta de salida", style = MaterialTheme.typography.titleMedium)
            OutlinedButton(onClick = { pickOutput.launch(null) }) { Text("Elegir carpeta de destino") }
            Text(outputUri?.lastPathSegment ?: "No seleccionada", color = MaterialTheme.colorScheme.onSurfaceVariant)

            Text("Conversiones simultáneas", style = MaterialTheme.typography.titleMedium)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                (1..4).forEach { count ->
                    FilterChip(
                        selected = concurrency == count,
                        onClick = { concurrency = count },
                        enabled = count <= maxConcurrency(context),
                        label = { Text(count.toString()) }
                    )
                }
            }
            Text("En dispositivos con poca memoria se recomienda una conversión a la vez.", style = MaterialTheme.typography.bodySmall)

            Button(
                enabled = pending.isNotEmpty() && outputUri != null,
                modifier = Modifier.fillMaxWidth(),
                onClick = {
                    val selected = pending.toList()
                    val destination = outputUri ?: return@Button
                    val direction = toBedrock
                    scope.launch {
                        try {
                            val loads = (0 until laneCount).map { lane ->
                                withContext(Dispatchers.IO) {
                                    workManager.getWorkInfosForUniqueWork("je2be-lane-$lane")
                                        .get().count { !it.state.isFinished }
                                }
                            }.toMutableList()
                            for (source in selected) {
                                val request = OneTimeWorkRequestBuilder<ConvertWorker>()
                                    .setInputData(
                                        workDataOf(
                                            ConvertWorker.KEY_INPUT to source.uri.toString(),
                                            ConvertWorker.KEY_INPUT_IS_TREE to source.isTree,
                                            ConvertWorker.KEY_INPUT_NAME to source.name,
                                            ConvertWorker.KEY_OUTPUT to destination.toString(),
                                            ConvertWorker.KEY_TO_BEDROCK to direction
                                        )
                                    )
                                    .addTag(ConvertWorker.TAG_CONVERSION)
                                    .build()
                                val lane = loads.indices.minByOrNull { loads[it] } ?: 0
                                loads[lane]++
                                workManager.enqueueUniqueWork(
                                    "je2be-lane-$lane",
                                    ExistingWorkPolicy.APPEND_OR_REPLACE,
                                    request
                                )
                            }
                            pending.clear()
                            statusText = "Se añadieron ${selected.size} trabajo(s) a la cola."
                        } catch (error: Exception) {
                            statusText = error.message ?: "No se pudo iniciar la cola."
                        }
                    }
                }
            ) { Text("Iniciar conversiones") }

            OutlinedButton(
                modifier = Modifier.fillMaxWidth(),
                onClick = {
                    workManager.cancelAllWorkByTag(ConvertWorker.TAG_CONVERSION)
                    statusText = "Se solicitó cancelar la cola."
                }
            ) { Text("Cancelar conversiones") }

            statusText?.let { Text(it, color = MaterialTheme.colorScheme.primary) }
            Text("Actividad", style = MaterialTheme.typography.titleLarge)
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(jobs.sortedByDescending { it.runAttemptCount }, key = { it.id }) { info ->
                    WorkCard(info)
                }
            }
        }
    }
}

@Composable
private fun WorkCard(info: WorkInfo) {
    val name = "Conversión ${info.id.toString().take(8)}"
    val percent = info.progress.getInt("pct", if (info.state == WorkInfo.State.SUCCEEDED) 100 else 0).coerceIn(0, 100)
    val stage = info.progress.getString("stage") ?: info.state.name
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Text(name, style = MaterialTheme.typography.titleSmall)
            LinearProgressIndicator(progress = { percent / 100f }, modifier = Modifier.fillMaxWidth())
            Text("$stage · $percent%", style = MaterialTheme.typography.bodySmall)
            info.outputData.getString("error")?.let { error ->
                Text(error, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
            }
            info.outputData.getString("outputName")?.let { output ->
                Text("Archivo creado: $output", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodySmall)
            }
            info.outputData.getString("resourcePackSummary")?.let { summary ->
                Text("Paquetes de recursos: $summary", style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

private fun takeReadPermission(context: android.content.Context, uri: Uri) {
    try {
        context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
    } catch (_: SecurityException) {
        // Some providers do not offer persistable grants; the worker will report an access error if needed.
    }
}

private fun queryDisplayName(context: android.content.Context, uri: Uri): String? {
    return context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
        if (cursor.moveToFirst()) cursor.getString(0) else null
    }
}

private fun maxConcurrency(context: android.content.Context): Int {
    val manager = context.getSystemService(ActivityManager::class.java)
    val memory = ActivityManager.MemoryInfo()
    manager.getMemoryInfo(memory)
    return (memory.totalMem / (1536L * 1024L * 1024L)).toInt().coerceIn(1, 4)
}

private fun defaultConcurrency(context: android.content.Context): Int = minOf(2, maxConcurrency(context))
