package app.je2be.android

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.ServiceInfo
import android.net.Uri
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.documentfile.provider.DocumentFile
import androidx.work.CoroutineWorker
import androidx.work.ForegroundInfo
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import app.je2be.android.resourcepacks.ResourcePackConverter
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class ConvertWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    private val nativeLock = Any()
    @Volatile private var nativeHandle: Long = 0L

    private fun foregroundInfo(title: String): ForegroundInfo {
        val manager = applicationContext.getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Conversiones", NotificationManager.IMPORTANCE_LOW)
        )
        val notification = NotificationCompat.Builder(applicationContext, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle(title)
            .setContentText("JE2BE está procesando un mundo")
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .build()
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ForegroundInfo(id.hashCode(), notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            ForegroundInfo(id.hashCode(), notification)
        }
    }

    override suspend fun getForegroundInfo(): ForegroundInfo = foregroundInfo("Preparando conversión")

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        val inputUri = inputData.getString(KEY_INPUT)?.let(Uri::parse)
            ?: return@withContext Result.failure(workDataOf("error" to "Falta el mundo de entrada."))
        val outputUri = inputData.getString(KEY_OUTPUT)?.let(Uri::parse)
            ?: return@withContext Result.failure(workDataOf("error" to "Falta la carpeta de salida."))
        val inputIsTree = inputData.getBoolean(KEY_INPUT_IS_TREE, true)
        val toBedrock = inputData.getBoolean(KEY_TO_BEDROCK, true)
        val resolver = applicationContext.contentResolver
        val sourceDocument = if (inputIsTree) {
            DocumentFile.fromTreeUri(applicationContext, inputUri)
        } else {
            DocumentFile.fromSingleUri(applicationContext, inputUri)
        } ?: return@withContext Result.failure(workDataOf("error" to "No se puede abrir el archivo seleccionado."))
        val outputDocument = DocumentFile.fromTreeUri(applicationContext, outputUri)
            ?: return@withContext Result.failure(workDataOf("error" to "No se puede abrir la carpeta de destino."))

        val jobDirectory = File(applicationContext.cacheDir, "je2be-jobs/$id")
        jobDirectory.deleteRecursively()
        if (!jobDirectory.mkdirs()) {
            return@withContext Result.failure(workDataOf("error" to "No se pudo crear el directorio temporal."))
        }
        val inputDirectory = File(jobDirectory, "input")
        val outputDirectory = File(jobDirectory, "output")
        val scratchDirectory = File(jobDirectory, "scratch")
        val displayName = safeFileName(inputData.getString(KEY_INPUT_NAME) ?: sourceDocument.name ?: "mundo")

        try {
            setForeground(foregroundInfo("Preparando $displayName"))
            setProgressAsync(workDataOf("stage" to "Copiando mundo", "pct" to 1))

            if (inputIsTree) {
                if (!sourceDocument.isDirectory) {
                    throw IllegalArgumentException("La entrada seleccionada no es una carpeta.")
                }
                copyTreeToFile(sourceDocument, inputDirectory)
            } else {
                val archive = File(jobDirectory, "input-world.zip")
                resolver.openInputStream(inputUri)?.use { source ->
                    FileOutputStream(archive).use { target -> source.copyTo(target) }
                } ?: throw IllegalStateException("No se pudo leer el archivo seleccionado.")
                extractZipSafely(archive, inputDirectory)
            }

            val worldRoot = findWorldRoot(inputDirectory)
                ?: throw IllegalArgumentException("No se encontró level.dat ni la estructura de un mundo Minecraft válido.")

            setProgressAsync(workDataOf("stage" to "Iniciando motor JE2BE", "pct" to 3))
            synchronized(nativeLock) { nativeHandle = Native.newJob() }
            if (nativeHandle == 0L) throw IllegalStateException("No se pudo iniciar el motor nativo.")
            if (isStopped) {
                Native.cancel(nativeHandle)
                return@withContext Result.failure(workDataOf("error" to "Conversión cancelada."))
            }

            val error = Native.convert(
                handle = nativeHandle,
                toBedrock = toBedrock,
                input = worldRoot.absolutePath,
                output = outputDirectory.absolutePath,
                tempRoot = scratchDirectory.absolutePath,
                listener = object : ProgressListener {
                    override fun onProgress(stage: String, done: Double, total: Double) {
                        val pct = if (total > 0.0) (3.0 + (done / total).coerceIn(0.0, 1.0) * 92.0).toInt() else 3
                        setProgressAsync(workDataOf("stage" to stage, "pct" to pct.coerceIn(3, 95)))
                    }
                },
                concurrency = 1
            )
            if (isStopped) return@withContext Result.failure(workDataOf("error" to "Conversión cancelada."))
            if (error != null) return@withContext Result.failure(workDataOf("error" to error))
            if (!outputDirectory.isDirectory || outputDirectory.listFiles().isNullOrEmpty()) {
                throw IllegalStateException("JE2BE no generó una carpeta de mundo de salida.")
            }

            setProgressAsync(workDataOf("stage" to "Revisando paquetes de recursos", "pct" to 96))
            val packResult = ResourcePackConverter.convertEmbeddedPacks(toBedrock, worldRoot, outputDirectory)

            setProgressAsync(workDataOf("stage" to "Creando archivo de mundo", "pct" to 97))
            val extension = if (toBedrock) "mcworld" else "zip"
            val outputName = "${displayName}-${if (toBedrock) "bedrock" else "java"}.$extension"
            val outputFile = outputDocument.createFile("application/zip", outputName)
                ?: throw IllegalStateException("No se pudo crear el archivo de salida.")
            try {
                resolver.openOutputStream(outputFile.uri, "w")?.use { stream ->
                    ZipOutputStream(stream.buffered()).use { zip -> zipDirectoryContents(outputDirectory, zip) }
                } ?: throw IllegalStateException("No se pudo escribir el archivo de salida.")
            } catch (error: Exception) {
                outputFile.delete()
                throw error
            }

            setProgressAsync(workDataOf("stage" to "Completado", "pct" to 100))
            Result.success(workDataOf(
                "outputName" to outputName,
                "direction" to if (toBedrock) "Java → Bedrock" else "Bedrock → Java",
                "resourcePackSummary" to "${packResult.convertedPacks} paquete(s), ${packResult.convertedPngTextures} textura(s) PNG trasladada(s)."
            ))
        } catch (error: Exception) {
            Result.failure(workDataOf("error" to (error.message ?: error.javaClass.simpleName)))
        } finally {
            synchronized(nativeLock) {
                val handle = nativeHandle
                nativeHandle = 0L
                if (handle != 0L) Native.freeJob(handle)
            }
            jobDirectory.deleteRecursively()
        }
    }

    override fun onStopped() {
        synchronized(nativeLock) {
            val handle = nativeHandle
            if (handle != 0L) Native.cancel(handle)
        }
        super.onStopped()
    }

    private fun copyTreeToFile(from: DocumentFile, target: File) {
        if (!target.exists() && !target.mkdirs()) throw IllegalStateException("No se pudo crear ${target.name}.")
        for (child in from.listFiles()) {
            val name = child.name ?: continue
            validateChildName(name)
            val destination = File(target, name)
            if (child.isDirectory) {
                copyTreeToFile(child, destination)
            } else {
                applicationContext.contentResolver.openInputStream(child.uri)?.use { input ->
                    FileOutputStream(destination).use { output -> input.copyTo(output) }
                } ?: throw IllegalStateException("No se pudo leer ${child.name}.")
            }
        }
    }

    private fun extractZipSafely(archive: File, target: File) {
        if (!target.mkdirs() && !target.isDirectory) throw IllegalStateException("No se pudo crear el directorio de extracción.")
        val root = target.canonicalFile
        ZipInputStream(FileInputStream(archive).buffered()).use { zip ->
            while (true) {
                val entry = zip.nextEntry ?: break
                val name = entry.name.replace('\\', '/')
                if (name.startsWith('/')) throw IllegalArgumentException("El ZIP contiene una ruta absoluta: $name")
                val segments = name.split('/').filter { it.isNotEmpty() && it != "." }
                if (segments.any { it == ".." }) throw IllegalArgumentException("El ZIP contiene una ruta no segura: $name")
                val normalizedName = segments.joinToString("/")
                if (normalizedName.isBlank()) {
                    if (entry.isDirectory) { zip.closeEntry(); continue }
                    throw IllegalArgumentException("El ZIP contiene un archivo sin nombre.")
                }
                val destination = File(root, normalizedName).canonicalFile
                if (destination != root && !destination.path.startsWith(root.path + File.separator)) {
                    throw IllegalArgumentException("El ZIP intenta escribir fuera del mundo.")
                }
                if (entry.isDirectory) {
                    if (!destination.mkdirs() && !destination.isDirectory) throw IllegalStateException("No se pudo extraer una carpeta.")
                } else {
                    destination.parentFile?.let { if (!it.mkdirs() && !it.isDirectory) throw IllegalStateException("No se pudo crear una carpeta del ZIP.") }
                    FileOutputStream(destination).use { output -> zip.copyTo(output) }
                }
                zip.closeEntry()
            }
        }
    }

    private fun findWorldRoot(root: File): File? {
        fun valid(dir: File): Boolean = File(dir, "level.dat").isFile &&
            (File(dir, "region").isDirectory || File(dir, "db").isDirectory || File(dir, "level.dat_old").exists())
        if (valid(root)) return root
        return root.walkTopDown().maxDepth(5).firstOrNull { it.isDirectory && valid(it) }
    }

    private fun zipDirectoryContents(root: File, zip: ZipOutputStream) {
        val canonicalRoot = root.canonicalFile
        fun add(directory: File, relative: String) {
            val children = directory.listFiles()?.sortedBy { it.name } ?: return
            for (child in children) {
                val canonical = child.canonicalFile
                if (canonical != canonicalRoot && !canonical.path.startsWith(canonicalRoot.path + File.separator)) {
                    throw IllegalStateException("La salida contiene una ruta fuera del mundo.")
                }
                val name = if (relative.isEmpty()) child.name else "$relative/${child.name}"
                if (child.isDirectory) {
                    zip.putNextEntry(ZipEntry("$name/"))
                    zip.closeEntry()
                    add(child, name)
                } else {
                    zip.putNextEntry(ZipEntry(name))
                    FileInputStream(child).buffered().use { it.copyTo(zip) }
                    zip.closeEntry()
                }
            }
        }
        add(root, "")
    }

    private fun validateChildName(name: String) {
        require(name != "." && name != ".." && '/' !in name && '\\' !in name) {
            "El almacenamiento devolvió un nombre de archivo no seguro."
        }
    }

    private fun safeFileName(value: String): String {
        val cleaned = value.substringBeforeLast('.', value).replace(Regex("[^A-Za-z0-9._-]"), "_").trim('_', '.')
        return cleaned.take(60).ifBlank { "mundo" }
    }

    companion object {
        const val KEY_INPUT = "in"
        const val KEY_INPUT_IS_TREE = "inputIsTree"
        const val KEY_INPUT_NAME = "inputName"
        const val KEY_OUTPUT = "out"
        const val KEY_TO_BEDROCK = "toBedrock"
        const val TAG_CONVERSION = "je2be-conversion"
        private const val CHANNEL_ID = "je2be-conversion"
    }
}
